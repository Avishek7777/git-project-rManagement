import java.util.Scanner;
import java.util.function.UnaryOperator;
public class Main{
    public static void main(String[] args) {
        Manager newMan= new Manager();
        Start newStart = new Start(newMan);
    }
}