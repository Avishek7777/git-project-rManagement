import java.util.jar.Attributes.Name;

public class Waiter extends Employee {
    private String shift;
    private String individual_id;
    private static int cID = 0;
    public Waiter(String Name, String email,String phNO, String Address,String shift,double salary){
        super(Name,email,phNO,Address,salary);
        this.shift =shift;
        cID ++;
        individual_id = "W-"+ cID;
    }

    public String getWaiterID(){
        return individual_id;
    }
    public void showDetails(){
        System.out.println("ID: "+individual_id);
        super.showEmployeeDetails(); 
        System.out.println("Shift: "+shift);

    }
    
}
