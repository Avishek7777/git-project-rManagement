#include<iostream>
using namespace std;
class scholarShip
{
    public :
    scholarShip(){
        cout<<"ScholarShip"<<endl;
    }
};
class TA{
    public :
    TA(){
        cout<<"TA"<<endl;
    }
};
class student : public scholarShip , public TA{
    public :
    student(){
        cout<<"Student"<<endl;
    }
};
class office{
    public:
    office(){
        cout<<"Office"<<endl;
    }
};
class Faculty{
    public:
    Faculty(){
        cout<<"FAculty"<<endl;
    }
};
class Employee: public Faculty , public office , public TA{
    public:
    Employee(){
        cout<<"Employee"<<endl;
    }
};
class person : public Employee , public student{
    public:
    person(){
        cout<<"Person "<<endl;
    }
};


int main(){
   person obj ;
}