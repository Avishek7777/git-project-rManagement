import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.jar.Attributes.Name;
public class Manager extends Employee{
    Manager(){
        super("MAnager-x","Manager-x@restaurant-x.com","+88017000000","Kuratoli",1000.00);
    }
    //private Main main = new Main();

    private String uname="Man";
    private String pwd="pass";
    private Waiter []waiters =new Waiter[3];

	
    public void setUName(String uname){
        this.uname = uname;
    }
    public void setManagerPwd(String pwd){
        this.pwd = pwd;
    }

    public String getUName(){
        return uname;
    }
    public String getPwd(){
        return pwd;
    }


    public void addWaiter(Waiter waiter)
	{
		for(int i=0; i<waiters.length; i++){
			if(waiters[i]==null){
				waiters[i] = waiter;
				break;
			}
			else{
				waiters= Arrays.copyOf(waiters, waiters.length+1);
				if(waiters[i]==null){
					waiters[i]=waiter;
					break;
				}

			}
		}


		/*
		boolean  flag = false;
		for (int i = 0; i<waiters.length; i++)
		{
			if (waiters[i] == null)
			{
				waiters[i] = waiter;
				flag = true;
				break;
			}
		}
		if (flag)
		{
			System.out.println ("New Waiter Account Added");
		}
		else
		{
			System.out.println ("Insertion Failed");
		}
		*/
	}

    public void removeWaiter(String individual_id)
	{
		boolean  flag = false;
		for (int i = 0; i<waiters.length; i++)
		{
			if(waiters[i]!=null){
				if (waiters[i].getWaiterID().equals(individual_id)){
					waiters[i] = null;
                	System.out.println (" Waiter Account Removed");
					flag = true;
					break;
				}
			}
		}
	}
    public void showAllWaiter(){
        for(int i=0;i<waiters.length; i++){
			if(waiters[i]!=null){
            	waiters[i].showDetails();
			}
        }
    }

    public void showDetails(){
        System.out.println("Name: "+this.getName());
		System.out.println("Email: "+this.getEmail());
		System.out.println("Phone Number: "+this.getphNo());
		System.out.println("Address: "+this.getAddress());
		System.out.println("Salary: "+this.getSalary());
    }
}