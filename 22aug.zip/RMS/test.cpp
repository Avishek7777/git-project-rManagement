#include<iostream>
using namespace std;
int main(){
    int n , m , k ;
    cin>>n>>m>>k;
    float x = ((float(n)/2)+(0.5));
    cout<<x<<endl;

    char bord[n][m];
    if(k,m,n>=1 && k,m,n<=100){
    if(n*m<k || n<k){
        cout<<"Imposible"<<endl;
    }else{
        cout<<"Possible"<<endl;
        for(int i = 0 ; i < n ; i++){
            for(int j = 0 ; j <m;j++){
                bord[i][j]='.';
            }
        }
        for(int i = 0 ; i< k ; i++){
            for(int j = 0 ; j <= x ; j++){
            bord[i+j][i]='*';
        }}
    for(int i = 0 ; i < n ; i++){
            for(int j = 0 ; j <m;j++){
                cout<<bord[i][j];
            }
            cout<<endl;
        }
    }
    }
}