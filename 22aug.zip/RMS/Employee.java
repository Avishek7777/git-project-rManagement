import java.util.jar.Attributes.Name;

public /*abstract*/ class Employee{
    private String Name;
    private String email;
    private String phNO;
    private String Address;
    private double salary;
    public Employee(String Name, String email,String phNO, String Address, double salary){
        this.Name =Name;
        this.email = email;
        this.phNO =phNO;
        this.Address =Address;
        this.salary = salary;
    }


    public void setName(String Name){
        this.Name = Name;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setphNO(String phNO){
        this.phNO =phNO;
    }
    public void setAddress(String Address){
        this.Address =Address;
    }
    public void setSalary(double salary){
        this.salary =salary;
    }




    public String getName(){
        return Name;
    }
    public String getEmail(){
        return email;
    }
    public String getphNo(){
        return phNO;
    }
    public String getAddress(){
        return Address;
    }
    public double getSalary(){
        return salary;
    }
    public void updateSalary(double salary){
        
    }
    public void showEmployeeDetails(){
        System.out.println("Name: "+Name);
        System.out.println("Email: "+email);
        System.out.println("Phone Number: "+ phNO);
        System.out.println("Address: "+Address);
        System.out.println("Address: "+salary);
    }
}