import java.util.Scanner;
public class Start{
    private String uName;
    private String pass;
    boolean matched;
    public Start(Manager manager) {
        Waiter w1 = new Waiter("Waiter-1","Waiter-1@restaurant-x.com","+88017000000","Bashundhara","day",2500.00);
		Waiter w2 = new Waiter("Waiter-2","Waiter-2@restaurant-x.com","+88016000000","Baridhara","night",2000.00);
		Waiter w3 = new Waiter("Waiter-3","Waiter-3@restaurant-x.com","+88018000000","Nikunja","day",3000.00);

		manager.addWaiter(w2);
		manager.addWaiter(w3);
        manager.addWaiter(w1);

        
        System.out.println("\nWelcome to Restaurant-x");
        byte x,x2,x3;
        Scanner sc =new Scanner(System.in);
        System.out.println("        1. Employee");
        System.out.println("        2. Customer");
        System.out.print("Please select what you want to do: ");
        x = sc.nextByte();
        switch(x){
            case 1 :
                System.out.println("        1. Manager");
                System.out.println("        2. Receptionist");
                System.out.println("        3. Waiter");
                System.out.println("        4. Other Workers");
                System.out.print("Please an option: ");
                x2 =sc.nextByte();
                switch(x2){
                    case 1 :
                        System.out.print("Enter the username: ");
                        sc.nextLine();
                        uName = sc.nextLine();
                        //sc.nextLine();
                        //System.out.println(uName);
                        System.out.print("Enter the pasword: ");
                        pass = sc.nextLine(); 
                        if(manager.getUName().equals(uName) && manager.getPwd().equals(pass)){
                            matched =true;
                            System.out.println("Cretentials Matched");
                            System.out.println("Select an option");
                            System.out.println("\t1. Food Management.");
                            System.out.println("\t2. Emplyee Management.");
                            System.out.println("\t3. Financial Report.");
                            x3= sc.nextByte();
                            switch(x3){
                                case 1:
                                    System.out.println("Select an Option");
                                    System.out.println("\t1. Add Stocks");
                                    System.out.println("\t2. Manage Order");
                                    x3 = sc.nextByte();
                                    // Stock function will be added
                                    break; 
                                case 2:
                                    System.out.println("\t1. Manager Account Details");
                                    System.out.println("\t2. Manage Employees");
                                    x3 = sc.nextByte();
                                    switch(x3){
                                        case 1:
                                            manager.showDetails();
                                            break;
                                        case 2:
                                        System.out.println("\t1. Show All Waiter");
                                            System.out.println("\t2. Add Waiter");
                                            System.out.println("\t3. Remove Waiter");
                                            x3 =sc.nextByte();
                                            switch(x3){
                                                case 1:
                                                    manager.showAllWaiter();
                                                    break;
                                                case 2:
                                                    manager.addWaiter(new Waiter("Swajan","swajan@restaurant-x.com","+88017000000000","Bashundhara","Night",23000));
                                                    manager.showAllWaiter();
                                                    break;
                                                case 3:
                                                    manager.removeWaiter("W-1");
                                                    System.out.println("---------------------After deleting----------------------");
                                                    manager.showAllWaiter();
                                                    break;
                                            }
                                            break;
                                        case 3:
                                            // Recitionist will be shown
                                            break;

                                    }
                                    break;
                                    case 3: 
                                        System.out.println("Financial Report Show Details  daily / weekly/ yearly");
                                        break;
                            }
                        }
                            else{
                                matched = false;
                                System.out.println("Wrong Credentials! Try again.");
                        }
                        
                    
                        break;
                    case 2 : 
                        System.out.println("Receptionist Details");
                        break;
                    case 3:
                        System.out.println("Login Page");
                        break;
                    case  4:
                        System.out.println("Login Page");
                        break;
                    default:
                        break;
                }
                break;
            case 2:
                System.out.println("Action Done");
                System.out.println("Foods we have");
                break;
            //case *:
                //break;
            default:
                break;
        }
    }
}
