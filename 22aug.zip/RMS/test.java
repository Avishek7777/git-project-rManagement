import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.event.*;
import java.awt.*;

class l extends JFrame implements ActionListener{
    private JLabel userlabel, passlabel;
    private JTextField tf;
    private JPasswordField pf;
    private JButton submitButton, clearButton , LoginButton;
   // private container c;
    private JOptionPane jOptionPane;
    private Font f;

l()
{
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setTitle(" Admin Pannel");
    this.getContentPane();
    this.setLayout(null);
    this.setBackground(Color.red);
    clearButton = new JButton(" clear button");
    f=new Font("Arial",Font.BOLD,10);
    userlabel=new JLabel("username");
    userlabel.setBounds(50,50,150,50);
    userlabel.setFont(f);
    this.add(userlabel);
    tf=new JTextField();
    tf.setFont(f);
    tf.setBounds(170,50,200,50);
    this.add(tf);
    passlabel=new JLabel("password:");
    passlabel.setBounds(50,120,150,50);
    passlabel.setFont(f);
    this.add(passlabel);
    pf=new JPasswordField();
    pf.setBounds(170,120,200,50);
    this.add(pf);
    pf.setEchoChar('*');
    pf.setFont(f);
    this.add(pf);
     LoginButton=new JButton("Log In");
    LoginButton.setBounds(280,190,90,50);
    this.add(clearButton);
    LoginButton.addActionListener(this);
    jOptionPane = new JOptionPane(); 
}
    public void actionPerfoemed(ActionEvent ae)
    {
        String userName=tf.getText();
    String password=pf.getText();
    if(userName.equals("admin") && password.equals("admin") && ae.getSource()==LoginButton)
        {
            jOptionPane.showInternalMessageDialog(null,"wellcome");
        }
         else{
            jOptionPane.showInternalMessageDialog(null," wrong");
         }   
       
      }

public static void main(String[] args) {
    l frame = new l();
    frame.setVisible(true);
}
}
