
        customer = new CustomerPage(this);