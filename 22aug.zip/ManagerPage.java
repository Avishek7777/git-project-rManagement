import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public abstract class ManagerPage {
    private JPanel testPanel ;
    test(){
    testPanel = new JPanel();
    testPanel.setLayout(null);
    testPanel.setBackground(new Color(126,130,192));
    testPanel.setBounds(400, 200, 400, 300);
    testPanel.setVisible(true);
    }
}
