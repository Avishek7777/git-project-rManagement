import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class Add_Remove_food extends JFrame implements ActionListener
 {
    JButton remove_button , add_button;
    JPanel addFoodPanel , removeFoodPanel ;
    JTextField foodName_add , Id_add , price;
    JTextField foodName_remove ,Id_remove ;
    Add_Remove_food(){

        foodName_add = new JTextField("Food Name");
        foodName_add.setLayout(null);
        foodName_add.setBounds(20,100,150,30);

        Id_add = new JTextField("ID");
        Id_add.setLayout(null);
        Id_add.setBounds(170,100,150,30);

        price = new JTextField("Price");
        price.setLayout(null);
        price.setBounds(320,100,150,30);

        foodName_remove = new JTextField("Food Name");
        foodName_remove.setLayout(null);
        foodName_remove.setBounds(70,100,150,30);

        Id_remove= new JTextField("ID");
        Id_remove.setLayout(null);
        Id_remove.setBounds(250,100,150,30);

        // Button :
        add_button = new JButton("Add");
        add_button.setBounds(200, 200, 100,50);
        add_button.setVisible(true);
        add_button.addActionListener(this);


        remove_button = new JButton("Remove");
        remove_button.setBounds(200, 200, 100,50);
        remove_button.setVisible(true);
        remove_button.addActionListener(this);

        //Panels :
        addFoodPanel = new JPanel();
         addFoodPanel.setLayout(null);
         addFoodPanel.setBackground(new Color(132,0,255));
         addFoodPanel.setBounds(0,0,500,400);
         addFoodPanel.setVisible(false);
         addFoodPanel.add(foodName_add);
         addFoodPanel.add(Id_add);
         addFoodPanel.add(price);
         addFoodPanel.add(add_button);

         removeFoodPanel = new JPanel();
         removeFoodPanel.setLayout(null);
         removeFoodPanel.setBackground(new Color(132,0,255));
         removeFoodPanel.setBounds(0,0,500,400);
         removeFoodPanel.add(foodName_remove);
         removeFoodPanel.add(Id_remove);
         removeFoodPanel.add(remove_button);
         removeFoodPanel.setVisible(false);

        this.setVisible(false);
        this.setLayout(null);
        this.setSize(500,400);
        this.add(addFoodPanel);
        this.add(removeFoodPanel);
        //this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==add_button){
            //code
        }else if(e.getSource()==remove_button){
            //code
        }
    }

   /*  public static void main(String[] args){
        Add_Remove_food obj = new Add_Remove_food();
    }*/
}
