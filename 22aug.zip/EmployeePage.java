import javax.swing.*;
import javax.swing.JTable;
import javax.swing.text.TabExpander;

import java.awt.event.*;
import java.awt.*;


class EmployeePage extends JFrame implements ActionListener{
    private JLabel label;
    private JLabel labelbgm;
    private JLabel BackgroundImage ;

    private JTable foodtable ;
    
    private JScrollPane ManagefoodPane ;

    private JButton login ;
    private JButton Back ;
    private JButton ManagerButton ;
    private JButton ManageOrder ;
    private JButton ManageFood , addFood,removeFood;
    private JButton ManageWaiter ;
    private JButton ShowAllEmployee ;
    private JButton Receptionist ;

    private JPanel ManagerPanel;
    private JPanel ReceptionistPanel ;
    private JPanel loginPanel;
    private JPanel ManageFoodPanel ;

    private JTextField username;
    private JPasswordField password;
    private HomePage homePage ;
    private boolean check ;
    private Add_Remove_food add_remove = new Add_Remove_food();
    EmployeePage(HomePage homePage){
        this.homePage = homePage;

     String[][] foodlist ={ 
            {"1","Pizza","300"},
            {"2" , "Burger" , "200"},
            {"3","Coffe","100"}
    };
    String[] foodlist_header ={"SL" ,"Name","Price"};

    //Tables :

    foodtable = new JTable(foodlist , foodlist_header);
    foodtable.setBounds(0,50 , 500,500);


    // Panes :
    ManagefoodPane = new JScrollPane();
    ManagefoodPane.setBounds(80,50,1000,400);
    ManagefoodPane.setBackground(new Color(1.0f , 1.0f ,1.0f , 0.6f));
    ManagefoodPane.setViewportView(foodtable);
    



// Buutons : 

    addFood = new JButton("Add Food");
    addFood.setBounds(850, 450, 100,50);
    addFood.setVisible(true);
    addFood.addActionListener(this);

    removeFood = new JButton("Remove Food ");
    removeFood.setBounds(950, 450, 100,50);
    removeFood.setVisible(true);
    removeFood.addActionListener(this);


    ManagerButton = new JButton("Manager");
    ManagerButton.setBounds(80,0,180,50);
    ManagerButton.setVisible(false);
    ManagerButton.addActionListener(this);

    Receptionist = new JButton("Receptionist");
    Receptionist.setBounds(260, 0,180, 50);
    Receptionist.setVisible(false);
    Receptionist.addActionListener(this);

    ManageFood = new JButton("Manage Food");
    ManageFood.setBounds(440, 0, 180, 50);
    ManageFood.setVisible(false);
    ManageFood.addActionListener(this);
    
    ManageWaiter = new JButton("Manage Waiter ");
    ManageWaiter.setBounds(620, 0, 180, 50);
    ManageWaiter.setVisible(false);
    ManageWaiter.addActionListener(this);

    ManageOrder = new JButton("Manage Order");
    ManageOrder.setBounds(800, 0, 180, 50);
    ManageOrder.setVisible(false);
    ManageOrder.addActionListener(this);

    ShowAllEmployee = new JButton("Show All Employee");
    ShowAllEmployee.setBounds(980, 0, 180, 50);
    ShowAllEmployee.setVisible(false);
    ShowAllEmployee.addActionListener(this);

/* Button End */
/* Panels for buttons  */
    ManagerPanel = new JPanel();
    ReceptionistPanel = new JPanel();
    ManageFoodPanel = new JPanel();

    //Manage Food Panels :
    ManageFoodPanel.setLayout(null);
    ManageFoodPanel.add(ManagefoodPane);
    ManageFoodPanel.setBackground(new Color(1.0f , 1.0f ,1.0f , 0.6f));
    ManageFoodPanel.setBounds(30,50,1150,700);
    ManageFoodPanel.add(addFood);
    ManageFoodPanel.add(removeFood);
    ManageFoodPanel.setVisible(false);

    //Receptionist Panel :
    ReceptionistPanel.setLayout(null);
    ReceptionistPanel.setBackground(new Color(1.0f , 1.0f ,1.0f , 0.6f));
    ReceptionistPanel.setBounds(30,50,1150,700);
    ReceptionistPanel.setVisible(false);
    //************ End of Receptionist Panels */


    // Manager Panel :
    ManagerPanel.setLayout(null);
    ManagerPanel.setBackground(new Color(1.0f , 1.0f ,1.0f , 0.6f));
    ManagerPanel.setBounds(30,50,1150,7000);
    ManagerPanel.setVisible(false);
    //*********************** End of Manager Buttons */

/* ************* End of Panels of Buttons */

// LOG IN Panel
    login = new JButton("Log In");
    login.setBounds(160, 240,70, 30);
    login.addActionListener(this);;
    Back = new JButton("Back");
    ImageIcon backimg = new ImageIcon("rsz_back_button.png");
    Back.setBounds(0,0,50,40);
    Back.addActionListener(this);
    Back.setIcon(backimg);
       

    username = new JTextField("User Name");
    username.setLayout(null);
    username.setBounds(120,180, 150 , 30);
    password = new JPasswordField("Password");
    password.setBounds(120 ,210, 150 , 30);

    label= new JLabel();
    label.setLayout(null);
    label.setText("Enter Your User name And Password");
    label.setBounds(80, 0, 600, 50);

    labelbgm = new JLabel();
    labelbgm.setLayout(null);
    labelbgm.setBounds(140,-140, 500,500);
    ImageIcon img = new ImageIcon("login.png");
    labelbgm.setIcon(img);


    loginPanel = new JPanel();
    loginPanel.setLayout(null);
    loginPanel.setBackground(new Color(255,255,255,190));
    loginPanel.setBounds(400, 200, 400, 300);
    loginPanel.add(username);
    loginPanel.add(password);
    loginPanel.add(label);
    loginPanel.add(labelbgm);
    loginPanel.add(login);
    loginPanel.setVisible(true);
//********************************  */
ImageIcon Background_image = new ImageIcon("Background_image.jpg");
    BackgroundImage = new JLabel(Background_image);
    BackgroundImage.setLayout(null);
    BackgroundImage.setBounds(0, 0, 1200, 800);
    this.setVisible(false);
    this.setLayout(null);
    this.setSize(1200,800);
    this.add(loginPanel);
    this.add(Back);
    this.add(ManagerPanel);
    this.add(ManageFoodPanel);
    this.add(ReceptionistPanel);
    this.add(ManagerButton);
    this.add(ManageFood);
    this.add(ManageOrder);
    this.add(ManageWaiter);
    this.add(ShowAllEmployee);
    this.add(Receptionist);
    this.add(BackgroundImage);
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
    }
    
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Back){
            homePage.setVisible(true);
            this.setVisible(false);
            loginPanel.setVisible(true);
            ManagerButton.setVisible(false);
            Receptionist.setVisible(false);
            ManageFood.setVisible(false);
            ManageOrder.setVisible(false);
            ManageWaiter.setVisible(false);
            ShowAllEmployee.setVisible(false);
            ManagerPanel.setVisible(false);
            ManageFoodPanel.setVisible(false);
            ReceptionistPanel.setVisible(false);
        }else if(e.getSource()==login){
            loginPanel.setVisible(false);
            ManagerButton.setVisible(true);
            ManageFood.setVisible(true);
            ManageOrder.setVisible(true);
            ManageWaiter.setVisible(true);
            ShowAllEmployee.setVisible(true);
            Receptionist.setVisible(true);
        }else if(e.getSource()==ManagerButton){
            ReceptionistPanel.setVisible(false);
            ManageFoodPanel.setVisible(false);
            ManagerPanel.setVisible(true);
        }else if (e.getSource()==Receptionist){
            ManagerPanel.setVisible(false);
            ManageFoodPanel.setVisible(false);
            ReceptionistPanel.setVisible(true);
        }else if(e.getSource()==ManageFood){
            ManageFoodPanel.setVisible(true);
            ManagerPanel.setVisible(false);
            ReceptionistPanel.setVisible(false);
        }else if(e.getSource()==removeFood){
            add_remove.setTitle("Remove Food");
            add_remove.setVisible(true);
            add_remove.addFoodPanel.setVisible(false);
            add_remove.removeFoodPanel.setVisible(true);
            
            
        }else if(e.getSource()==addFood){
            add_remove.setVisible(true);
            add_remove.setTitle("Add Food");
            add_remove.removeFoodPanel.setVisible(false);
            add_remove.addFoodPanel.setVisible(true);
            
        }
    }
    /*public static void main(String[] args){
       
        EmployeePage obj = new EmployeePage(new HomePage());
    }*/

}
